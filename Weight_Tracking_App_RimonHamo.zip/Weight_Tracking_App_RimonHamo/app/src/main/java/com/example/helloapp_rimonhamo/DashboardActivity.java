package com.example.helloapp_rimonhamo;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class DashboardActivity extends AppCompatActivity {

    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        username = getIntent().getStringExtra("username");

        TextView tvWelcome = findViewById(R.id.tvWelcome);
        if (username != null && !username.isEmpty()) {
            tvWelcome.setText("Hello, " + username + "!");
        } else {
            tvWelcome.setText("Hello, User!");
        }

        // View History
        findViewById(R.id.btnViewHistory).setOnClickListener(v -> {
            Intent intent = new Intent(this, HistoryActivity.class);
            intent.putExtra("username", username);
            startActivity(intent);
        });

        // SMS Permission
        findViewById(R.id.btnSMSPermission).setOnClickListener(v ->
                startActivity(new Intent(this, SMSPermissionActivity.class)));

        // Set Goal
        findViewById(R.id.btnSetGoal).setOnClickListener(v -> showSetGoalDialog());
    }

    private void showSetGoalDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Set Your Goal Weight (lbs)");

        final android.widget.EditText input = new android.widget.EditText(this);
        input.setHint("Enter goal (e.g. 150)");
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        builder.setView(input);

        builder.setPositiveButton("Save Goal", (dialog, which) -> {
            String goalStr = input.getText().toString().trim();
            if (!goalStr.isEmpty()) {
                try {
                    float goal = Float.parseFloat(goalStr);
                    SharedPreferences prefs = getSharedPreferences("UserGoals", MODE_PRIVATE);
                    prefs.edit().putFloat("goalWeight", goal).apply();
                    Toast.makeText(this, "Goal saved: " + goal + " lbs", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(this, "Invalid number", Toast.LENGTH_SHORT).show();
                }
            }
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }
}