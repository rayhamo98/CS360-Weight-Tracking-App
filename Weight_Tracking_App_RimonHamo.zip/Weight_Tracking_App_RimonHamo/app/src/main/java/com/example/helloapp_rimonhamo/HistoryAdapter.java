package com.example.helloapp_rimonhamo;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.ViewHolder> {

    private ArrayList<DatabaseHelper.WeightEntry> historyList;
    private final HistoryActivity activity;

    public HistoryAdapter(ArrayList<DatabaseHelper.WeightEntry> historyList, HistoryActivity activity) {
        this.historyList = historyList;
        this.activity = activity;
    }

    public void updateData(ArrayList<DatabaseHelper.WeightEntry> newList) {
        this.historyList = newList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_history_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        DatabaseHelper.WeightEntry entry = historyList.get(position);

        holder.tvDate.setText(entry.date);
        holder.tvWeight.setText(String.valueOf(entry.weight));   // Only number, no unit

        // Fixed delete - uses unique ID
        holder.btnDelete.setOnClickListener(v -> {
            activity.deleteWeight(entry.id);
        });
    }

    @Override
    public int getItemCount() {
        return historyList.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvDate, tvWeight;
        Button btnDelete;

        ViewHolder(View itemView) {
            super(itemView);
            tvDate = itemView.findViewById(R.id.tvDate);
            tvWeight = itemView.findViewById(R.id.tvWeight);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}