package com.example.helloapp_rimonhamo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "weight_tracker.db";
    private static final int DATABASE_VERSION = 2;   // Increased version

    // Users table
    private static final String TABLE_USERS = "users";
    private static final String COL_USER_ID = "id";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD = "password";

    // Weight entries table
    private static final String TABLE_WEIGHTS = "weight_entries";
    private static final String COL_WEIGHT_ID = "id";
    private static final String COL_DATE = "date";
    private static final String COL_WEIGHT = "weight";
    private static final String COL_UNIT = "unit";        // "kg" or "lbs"
    private static final String COL_USER = "username";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createUsers = "CREATE TABLE " + TABLE_USERS + " (" +
                COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USERNAME + " TEXT UNIQUE, " +
                COL_PASSWORD + " TEXT)";
        db.execSQL(createUsers);

        String createWeights = "CREATE TABLE " + TABLE_WEIGHTS + " (" +
                COL_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_DATE + " TEXT, " +
                COL_WEIGHT + " REAL, " +
                COL_UNIT + " TEXT DEFAULT 'kg', " +
                COL_USER + " TEXT)";
        db.execSQL(createWeights);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE " + TABLE_WEIGHTS + " ADD COLUMN " + COL_UNIT + " TEXT DEFAULT 'kg'");
        }
    }

    // === USER METHODS ===
    public boolean registerUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD, password);
        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS +
                        " WHERE " + COL_USERNAME + "=? AND " + COL_PASSWORD + "=?",
                new String[]{username, password});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    // Add weight with unit
    public boolean addWeight(String date, double weight, String unit, String username) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_DATE, date);
        values.put(COL_WEIGHT, weight);
        values.put(COL_UNIT, unit);
        values.put(COL_USER, username);
        long result = db.insert(TABLE_WEIGHTS, null, values);
        return result != -1;
    }

    // Get weights with unit
    public ArrayList<WeightEntry> getAllWeights(String username) {
        ArrayList<WeightEntry> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT " + COL_WEIGHT_ID + ", " + COL_DATE + ", " + COL_WEIGHT + ", " + COL_UNIT +
                        " FROM " + TABLE_WEIGHTS +
                        " WHERE " + COL_USER + "=? ORDER BY " + COL_DATE + " DESC, " + COL_WEIGHT_ID + " DESC",
                new String[]{username});

        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String date = cursor.getString(1);
            double weight = cursor.getDouble(2);
            String unit = cursor.getString(3);
            list.add(new WeightEntry(id, date, weight, unit));
        }
        cursor.close();
        return list;
    }

    public boolean deleteWeightById(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(TABLE_WEIGHTS, COL_WEIGHT_ID + "=?", new String[]{String.valueOf(id)});
        return rows > 0;
    }

    // Inner class
    public static class WeightEntry {
        public final int id;
        public final String date;
        public final double weight;
        public final String unit;

        public WeightEntry(int id, String date, double weight, String unit) {
            this.id = id;
            this.date = date;
            this.weight = weight;
            this.unit = unit != null ? unit : "kg";
        }
    }
}