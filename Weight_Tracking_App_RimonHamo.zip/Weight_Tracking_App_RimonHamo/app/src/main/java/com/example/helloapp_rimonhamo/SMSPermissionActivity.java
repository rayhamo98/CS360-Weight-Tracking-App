package com.example.helloapp_rimonhamo;

import static com.example.helloapp_rimonhamo.R.*;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SMSPermissionActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 101;

    private Button btnRequestPermission, btnSendSMS;
    private TextView tvPermissionStatus;
    private Switch switchSMS;
    private EditText etPhoneNumber, etMessage;

    private boolean smsPermissionGranted = false;
    private boolean smsFeatureEnabled = false;

    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        // UI Elements
        btnRequestPermission = findViewById(R.id.btnRequestPermission);
        btnSendSMS = findViewById(R.id.btnSendTestSMS);
        tvPermissionStatus = findViewById(R.id.tvPermissionStatus);
        switchSMS = findViewById(R.id.switchSMS);
        etPhoneNumber = findViewById(R.id.etTestPhone);
        etMessage = findViewById(R.id.etTestMessage);

        prefs = getSharedPreferences("AppPrefs", MODE_PRIVATE);

        // Load saved toggle state
        smsFeatureEnabled = prefs.getBoolean("smsFeatureEnabled", false);

        checkPermissionStatus();

        // Request permission button
        btnRequestPermission.setOnClickListener(v -> requestSMSPermission());

        // Switch toggle
        switchSMS.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                if (!smsPermissionGranted) {
                    requestSMSPermission();
                    switchSMS.setChecked(false);
                } else {
                    smsFeatureEnabled = true;
                    saveToggleState(true);
                    tvPermissionStatus.setText("✅ SMS Notifications Enabled");
                }
            } else {
                smsFeatureEnabled = false;
                saveToggleState(false);
                tvPermissionStatus.setText("❌ SMS Notifications Disabled");
            }
        });

        // Send SMS button
        btnSendSMS.setOnClickListener(v -> {
            if (!smsFeatureEnabled) {
                Toast.makeText(this, "Enable SMS Notifications first", Toast.LENGTH_SHORT).show();
                return;
            }

            String phone = etPhoneNumber.getText().toString().trim();
            String message = etMessage.getText().toString().trim();

            if (phone.isEmpty() || message.isEmpty()) {
                Toast.makeText(this, "Enter phone number and message", Toast.LENGTH_SHORT).show();
                return;
            }

            sendTestSMS(phone, message);
        });
    }

    private void checkPermissionStatus() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {

            smsPermissionGranted = true;

            if (smsFeatureEnabled) {
                tvPermissionStatus.setText("✅ SMS Notifications Enabled");
                switchSMS.setChecked(true);
            } else {
                tvPermissionStatus.setText("❌ SMS Notifications Disabled");
                switchSMS.setChecked(false);
            }

            btnRequestPermission.setEnabled(false);

        } else {
            smsPermissionGranted = false;
            tvPermissionStatus.setText("❌ SMS Permission Required");
            switchSMS.setChecked(false);
            btnRequestPermission.setEnabled(true);
        }
    }

    private void requestSMSPermission() {
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.SEND_SMS},
                SMS_PERMISSION_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                smsPermissionGranted = true;
                smsFeatureEnabled = true;
                saveToggleState(true);

            } else {
                smsPermissionGranted = false;
                smsFeatureEnabled = false;
                saveToggleState(false);
            }

            checkPermissionStatus();
        }
    }

    private void sendTestSMS(String phoneNumber, String message) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);

            // Emulator won't actually receive it — simulate success
            Toast.makeText(this, "📩 SMS Sent (Emulator simulation)", Toast.LENGTH_SHORT).show();

            // Update UI to make it look real
            tvPermissionStatus.setText("📩 Last SMS Sent To: " + phoneNumber);

        } catch (Exception e) {
            Toast.makeText(this, "SMS Failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

    private void saveToggleState(boolean state) {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean("smsFeatureEnabled", state);
        editor.apply();
    }
}