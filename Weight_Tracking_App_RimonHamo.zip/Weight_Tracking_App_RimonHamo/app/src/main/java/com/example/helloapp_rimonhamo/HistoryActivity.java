package com.example.helloapp_rimonhamo;

import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import android.Manifest;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import androidx.core.content.ContextCompat;

public class HistoryActivity extends AppCompatActivity {

    private RecyclerView recyclerHistory;
    private Button btnAddWeight;
    private Button btnToggleUnit;
    private DatabaseHelper dbHelper;
    private HistoryAdapter adapter;
    private String currentUsername;
    private boolean isKg = true;   // default to kg

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        dbHelper = new DatabaseHelper(this);

        currentUsername = getIntent().getStringExtra("username");
        if (currentUsername == null || currentUsername.isEmpty()) {
            currentUsername = "default_user";
        }

        recyclerHistory = findViewById(R.id.recyclerHistory);
        btnAddWeight = findViewById(R.id.btnAddWeight);
        btnToggleUnit = findViewById(R.id.btnToggleUnit);

        recyclerHistory.setLayoutManager(new LinearLayoutManager(this));

        loadWeightsFromDatabase();

        btnAddWeight.setOnClickListener(v -> showAddWeightDialog());

        btnToggleUnit.setOnClickListener(v -> {
            isKg = !isKg;
            btnToggleUnit.setText(isKg ? "Switch to lbs" : "Switch to kg");
            loadWeightsFromDatabase();
        });
    }

    private void loadWeightsFromDatabase() {
        ArrayList<DatabaseHelper.WeightEntry> originalList = dbHelper.getAllWeights(currentUsername);

        ArrayList<DatabaseHelper.WeightEntry> displayList = new ArrayList<>();
        for (DatabaseHelper.WeightEntry entry : originalList) {
            double displayWeight = entry.weight;
            String displayUnit = isKg ? "kg" : "lbs";

            if (!isKg && "kg".equals(entry.unit)) {
                displayWeight = entry.weight * 2.20462;
            } else if (isKg && "lbs".equals(entry.unit)) {
                displayWeight = entry.weight / 2.20462;
            }

            displayList.add(new DatabaseHelper.WeightEntry(entry.id, entry.date, displayWeight, displayUnit));
        }

        if (adapter == null) {
            adapter = new HistoryAdapter(displayList, this);
            recyclerHistory.setAdapter(adapter);
        } else {
            adapter.updateData(displayList);
        }
    }

    private void showAddWeightDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.custom_dialog, null);

        EditText etDate = dialogView.findViewById(R.id.etDate);
        EditText etWeight = dialogView.findViewById(R.id.etWeight);

        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        etDate.setText(today);
        etWeight.setHint("Enter weight");

        builder.setView(dialogView)
                .setTitle("Add Today's Weight")
                .setPositiveButton("Save", (dialog, which) -> {
                    String date = etDate.getText().toString().trim();
                    String weightStr = etWeight.getText().toString().trim();

                    if (date.isEmpty() || weightStr.isEmpty()) {
                        Toast.makeText(this, "Date and weight are required", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    try {
                        double weight = Double.parseDouble(weightStr);
                        String unit = isKg ? "kg" : "lbs";

                        if (dbHelper.addWeight(date, weight, unit, currentUsername)) {
                            Toast.makeText(this, "Weight saved!", Toast.LENGTH_SHORT).show();

                            // Call the correct method
                            checkForGoalReached(weight);

                            loadWeightsFromDatabase();
                        } else {
                            Toast.makeText(this, "Failed to save", Toast.LENGTH_SHORT).show();
                        }
                    } catch (NumberFormatException e) {
                        Toast.makeText(this, "Invalid weight", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // This is the ONLY checkForGoalReached method now
    private void checkForGoalReached(double newWeight) {
        SharedPreferences prefs = getSharedPreferences("UserGoals", MODE_PRIVATE);
        float goalWeight = prefs.getFloat("goalWeight", 150.0f);   // default 150 lbs

        if (newWeight <= goalWeight) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                String emulatorNumber = "555-123-4567";

                String message = "Congratulations " + currentUsername + "! You reached your goal ("
                        + newWeight + " lbs). Goal was " + goalWeight + " lbs";

                smsManager.sendTextMessage(emulatorNumber, null, message, null, null);

                Toast.makeText(this, "Goal Reached - SMS Sent!", Toast.LENGTH_LONG).show();

            } catch (Exception e) {
                Toast.makeText(this, "Failed to send SMS", Toast.LENGTH_LONG).show();
            }
        }
    }

    public void deleteWeight(int weightId) {
        if (dbHelper.deleteWeightById(weightId)) {
            Toast.makeText(this, "Entry deleted", Toast.LENGTH_SHORT).show();
            loadWeightsFromDatabase();
        } else {
            Toast.makeText(this, "Failed to delete", Toast.LENGTH_SHORT).show();
        }
    }
}